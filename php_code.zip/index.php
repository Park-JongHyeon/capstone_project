<?php
 session_start();
 if(!isset($_SESSION['user_id'])){
  if(isset($_COOKIE['user_id']) && isset($_COOKIE['username'])){
   $_SESSION['user_id'] = $_COOKIE['user_id'];
   $_SESSION['username'] = $_COOKIE['username'];
  }
 }

?>

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
 <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
 <title>Ki-Word Admin Page</title>
 <link rel="stylesheet" type="text/css" href="style.css" />
</head>
 <h3>Ki-Word Admin Page</h3>

<?php
 if(!isset($_SESSION['user_id'])){
  echo '<p class="login">You must log in</p>';
  exit();
 } 
 else{
  echo '<a href="userAdmin.php">User Table Manage</a><br />';
  echo '<a href="wordAdmin.php">Word Table Manage</a><br />';
  echo '<a href="logout.php">Log Out</a><br />';
 }
?>
