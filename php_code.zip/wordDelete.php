<?php
 session_start();

 if(!isset($_SESSION['user_id'])){
  if(isset($_COOKIE['user_id']) && isset($_COKKIE['username'])){
   $_SESSION['user_id'] = $_COOKIE['user_id'];
   $_SESSION['username'] = $_COOKIE['username'];
  }
 }
?>

<?php

if(!isset($_SESSION['user_id'])){
 echo '<p class="login">You must log in.</p>';
 exit();
}

else{
$dbc = mysqli_connect('localhost', 'root', '12345', 'KiWord_db');

echo '<a href="wordAdmin.php">Back</a><br />';
echo '<a href="logout.php">Log Out</a><br />';

if(isset($_POST['Delete_submit2'])){
 $word_no = mysqli_real_escape_string($dbc, trim($_POST['No']));

 $query = "SELECT * FROM wordInfo_tb WHERE No = '$word_no'";
 $data = mysqli_query($dbc, $query);

 if(mysqli_num_rows($data) == 1){
  $query = "DELETE FROM wordInfo_tb WHERE No = '$word_no'";
  mysqli_query($dbc, $query);
  echo '<p>Word Deleted successfully.</p>';
  mysqli_close($dbc);
 }
 else{
  echo '<p class="error">Word Number does not exist. Check again.</p>';
  $word_no = "";
 }
}
}
?>

<html>
<head>
 <title>Ki-Word Admin Page</title>
 <link rel="stylesheet" type="text/css" href="style.css" />
</head>
<body>
 <h3>Ki-Word Admin Page - Delete Word</h3>
<form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
 <fieldset>
 <label for="No">Word Number</label>
 <input type="text" id="No" name="No" />

 <input type="submit" value="Delete" name="Delete_submit2" />
 </fieldset>
</form>
</body>
</html>