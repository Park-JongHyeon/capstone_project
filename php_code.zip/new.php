<?php
 $dbc = mysqli_connect('localhost', 'root', '12345', 'KiWord_db');

 $ID = $_POST['ID'];
 $PW = $_POST['PW'];
 $Name = $_POST['Name'];

 $query = "SELECT * FROM userInfo_tb WHERE ID = '$ID'";
 $data = mysqli_query($dbc, $query);

 if(mysqli_num_rows($data) == 0){
  $query = "INSERT INTO userInfo_tb (ID, PW, Name, Authority, Coin, Score) VALUES ('$ID', '$PW', '$Name', '0', '0', '0')";
  mysqli_query($dbc, $query);
  echo '<p>Success';
  mysqli_close($dbc);
}

 else{
  echo "Fail";
 }

?>