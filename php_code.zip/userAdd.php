<?php
 session_start();

 if(!isset($_SESSION['user_id'])){
  if(isset($_COOKIE['user_id']) && isset($_COOKIE['username'])){
   $_SESSION['user_id'] = $_COOKIE['user_id'];
   $_SESSION['username'] = $_COOKIE['username'];
  }
 }
?>

<?php
 if(!isset($_SESSION['user_id'])){
  echo '<p class="login">You must log in.</p>';
  exit();
 }
 else{
  $dbc = mysqli_connect('localhost', 'root', '12345', 'KiWord_db');

  echo '<a href="userAdmin.php">Back</a><br />';
  echo '<a href="logout.php">Log out</a><br />';

  if(isset($_POST['Add1'])){
   $userID = mysqli_real_escape_string($dbc, trim($_POST['userID']));
   $userPW = mysqli_real_escape_string($dbc, trim($_POST['userPW']));
   $userName = mysqli_real_escape_string($dbc, trim($_POST['userName']));
   $userAuth = mysqli_real_escape_string($dbc, trim($_POST['userAuth']));
   $coin = mysqli_real_escape_string($dbc, trim($_POST['coin']));
   $score = mysqli_real_escape_string($dbc, trim($_POST['score']));

   $query = "SELECT * FROM userInfo_tb WHERE ID = '$userID'";
   $data = mysqli_query($dbc, $query);

   if(mysqli_num_rows($data) == 1){
    echo '<p class="error">User ID already exists.<p>';
    $userID = "";
   }
  else{
   $query = "INSERT INTO userInfo_tb (ID, PW, Name, Authority, Coin, Score) VALUES ('$userID', '$userPW', '$userName', '$userAuth', '$coin', '$score')";
   mysqli_query($dbc, $query);
   echo '<p>User Added successfully.<p>';
   mysqli_close($dbc);
   }
  }
 }
?>

<html>
<head>
 <title>Ki-Word Admin Page</title>
 <link rel="stylesheet" type="text/css" href="style.css" />
</head>
<body>
 <h3>Ki-Word Admin Page - Add User</h3>
<form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
 <fieldset>
 <label for="userID">User ID</label>
 <input type="text" id="userID" name="userID" />

 <label for="userPW">User PW</label>
 <input type="text" id="userPW" name="userPW" />

 <label for="userName">User Name</label>
 <input type="text" id="userName" name="userName" />

 <label for="userAuth">User Authority</label>
 <input type="text" id="userAuth" name="userAuth" />

 <label for="coin">Coin</label>
 <input type="text" id="coin" name="coin" />

 <label for="score">Score</label>
 <input type="text" id="score" name="score" />

 <input type="submit" value="Add" name="Add1" />
 </fieldset>
</form>
</body>
</html>