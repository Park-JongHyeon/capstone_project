<?php
 mysql_connect('localhost', 'root', '12345') or die(mysql_error());
 mysql_select_db('KiWord_db');

 $userName = $_POST["Nick"];

 $query = "SELECT * FROM userInfo_tb order by Score asc";
 $data = mysql_query($query) or die(mysql_error());
 $rankCounter = 1;

 while($row=mysql_fetch_array($data)){
  $name=$row['Name'];
  $score=$row['Score'];
  echo ("$name" . "/" . "$score" . "/");
 }
?>
