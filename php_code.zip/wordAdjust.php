<?php
 session_start();

 if(!isset($_SESSIO['user_id'])){
  if(isset($_COOKIE['user_id']) && isset($_COOKIE['username'])){
   $_SESSION['user_id'] = $_COOKIE['user_id'];
   $_SESSION['username'] = $_COOKIE['username'];
  }
 }
?>

<?php

 if(!isset($_SESSION['user_id'])){
  echo '<p class="login">You must log in.</p>';
  exit();
 }

 else{
  $dbc = mysqli_connect('localhost', 'root', '12345', 'KiWord_db');

  echo '<a href="wordAdmin.php">Back</a><br />';
  echo '<a href="logout.php">Log Out</a><br />';

  if(isset($_POST['Alter2'])){
   $word_no1 = mysqli_real_escape_string($dbc, trim($_POST['wordNo1']));
   $word_no2 = mysqli_real_escape_string($dbc, trim($_POST['wordNo2']));
   $word = mysqli_real_escape_string($dbc, trim($_POST['word']));
   $category = mysqli_real_escape_string($dbc, trim($_POST['category']));

   $query = "SELECT * FROM wordInfo_tb WHERE No = '$word_no1'";
   $data = mysqli_query($dbc, $query);

   if(mysqli_num_rows($data) == 0){
    echo '<p class="error">There is no such word number. Check again.</p>';
    $word_no = "";
   }
   else{
    $query = "UPDATE wordInfo_tb SET No='$word_no2', Word='$word', Category='$category' WHERE No='$word_no1'";
    mysqli_query($dbc, $query);
    echo '<p>Word Adjusted successfully.</p>';
    mysqli_close($dbc);
   }
  }
 }
?>

<html>
 <title>Ki-Word Admin Page</title>
 <link rel="stylesheet" type="text/css" href="style.css" />
</head>
<body>
 <h3>Ki-Word Admin Page - Adjust User</h3>
<form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
 <fieldset>
 <legend>Enter Word Number that you want to adjust</legend>
 <label for="wordNo1">Word Number</label>
 <input type="text" id="wordNo1" name="wordNo1" />
 </fieldset>

 <fieldset>
 <legend>Adjust information</legend>
 <label for="wordNo2">Word Number</label>
 <input type="text" id="wordNo2" name="wordNo2" />

 <label for="word">Word</label>
 <input type="text" id="word" name="word" />

 <label for="category">Category</label>
 <input type="text" id="category" name="category" />

 <input type="submit" value="Alter2" name="Alter2">
 </fieldset>
</form>
</body>
</html>
