<?php
 session_start();
 $error_msg = "";

 if(!isset($_SESSION['user_id'])){
  if(isset($_POST['submit'])){
   $dbc = mysqli_connect('localhost', 'root', '12345', 'KiWord_db')
   or die('Error Connecting to MySQL server.');

   $user_id = mysqli_real_escape_string($dbc, trim($_POST['ID']));
   $user_pw = mysqli_real_escape_string($dbc, trim($_POST['PW']));

   if(!empty($user_id) && !empty($user_pw)){
    $query = "SELECT ID, PW  FROM userInfo_tb WHERE ID = '$user_id' AND " .
    "PW = '$user_pw' AND Authority = 1";
    $data = mysqli_query($dbc, $query);

    if (mysqli_num_rows($data) == 1){
     $row = mysqli_fetch_array($data);
     $_SESSION['user_id'] = $row['ID'];
     $_SESSION['username'] = $row['Name'];
     setcookie('ID', $row['ID']);
     setcookie('PW', $row['PW']);
     $home_url = 'http://' . $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']) . '/index.php';
     header('Location: ' . $home_url);
     mysqli_close($dbc);
    }

   else{
    $error_msg = 'Sorry, you must enter a valid id and password.';
   }
  }
  else{
   $error_msg = 'Sorry, you must enter your ID and password.';
  }
 }
}

?>


<html>
<head>
 <title>Ki-Word Login</title>
</head>
<body>
 <h3>Ki-Word Admin LogIn</h3>

<?php
 if(empty($_SESSION['user_id'])){
  echo '<p class="error">' . $error_msg . '</p>';
?>

<form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
 <fieldset>
  <legend>Log In</legend>
  <label for="ID">ID:</label>
  <input type="text" id="ID" name="ID"
   value="<?php if (!empty($user_id)) echo $user_id; ?>" /><br />
  <label for="PW">PW:</label>
  <input type="password" id="PW" name="PW" />
 </fieldset>
<br> <input type="submit" value="LogIn" name="submit" /><br />
</form>

<?php
}
else {
echo('<p class="login">You are logged in as' . $_SESSION['username'] .  '.</p>');
}
?>

</body>
</html>