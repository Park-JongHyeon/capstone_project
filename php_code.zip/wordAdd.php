<?php
 session_start();

 if(!isset($_SESSION['user_id'])){
  if(isset($_COOKIE['user_id']) && isset($_COOKIE['username'])){
   $_SESSION['user_id'] = $_COOKIE['user_id'];
   $_SESSION['username'] = $_COOKIE['username'];
  }
 }
?>

<?php

 if(!isset($_SESSION['user_id'])){
  echo '<p class="login">You must log in.</p>';
 }

 else{
  $dbc = mysqli_connect('localhost', 'root', '12345', 'KiWord_db');

  echo '<a href="wordAdmin.php">Back</a><br />';
  echo '<a href="logout.php">Log Out</a><br />';

  if(isset($_POST['Add_submit2'])){
   $word_no = mysqli_real_escape_string($dbc, trim($_POST['No']));
   $word = mysqli_real_escape_string($dbc, trim($_POST['Word']));
   $category = mysqli_real_escape_string($dbc, trim($_POST['Category']));

   $query = "SELECT * FROM wordInfo_tb WHERE No = '$word_no'";
   $data = mysqli_query($dbc, $query);

   if(mysqli_num_rows($data) == 0){
    $query = "INSERT INTO wordInfo_tb (No, Word, Category) VALUES ('$word_no', '$word', '$category')";
    mysqli_query($dbc, $query);
    echo '<p>Word Added successfully.</p>';
    echo "$word";
    mysqli_close($dbc);
   }

   else{
    echo '<p class="error">Word number already exists. Check again.</p>';
    $word_no = "";
   }
  }
 }
?>

<html>
<head>
 <title>Ki-Word Admin Page</title>
 <link rel="stylesheet" type="text/css" href="style.css" />
</head>
<body>
 <h3>Ki-Word Admin Page - Add Word</h3>
<form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
 <fieldset>
 <label for="No">Word Number</label>
 <input type="text" id="No" name="No" />

 <label for="Word">Word</label>
 <input type="text" id="Word" name="Word" />

 <label for="Category">Category</label>
 <input type="text" id="Category" name="Category" />

 <input type="submit" value="Add" name="Add_submit2" />
 </fieldset>
</form>
</body>
</html>
