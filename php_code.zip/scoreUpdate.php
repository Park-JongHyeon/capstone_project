<?php
 $dbc = mysqli_connect('localhost', 'root', '12345', 'KiWord_db');

 $Name = $_POST['Nick'];
 $newScore = $_POST['SCORE'];

 $query = "SELECT * FROM userInfo_tb WHERE Name = '$Name'";
 $data = mysqli_query($dbc, $query);

 if(mysqli_num_rows($data) == 1){
  $query = "UPDATE userInfo_tb SET Score='$newScore' WHERE Name='$Name'";
  mysqli_query($dbc, $query);
  mysqli_close($dbc);
 }
 else{
  echo 'Fail';
 }
?>