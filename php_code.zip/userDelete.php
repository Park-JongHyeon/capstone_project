<?php
 session_start();

 if(!isset($_SESSION['user_id'])){
  if(isset($_COOKIE['user_id']) && isset($_COOKIE['username'])){
   $_SESSION['user_id'] = $_COOKIE['user_id'];
   $_SESSION['username'] = $_COOKIE['username'];
  }
 }
?>


<?php

 if(!isset($_SESSION['user_id'])){
  echo '<p class="login">You must log in.</p>';
  exit();
 }
 else{
  $dbc = mysqli_connect('localhost', 'root', '12345', 'KiWord_db');

  echo '<a href="userAdmin.php">Back</a><br />';
  echo '<a href="logout.php">Log Out</a><br />';

  if(isset($_POST['Delete_submit1'])){
   $userID = mysqli_real_escape_string($dbc, trim($_POST['userID']));

   $query = "SELECT * FROM userInfo_tb WHERE ID = '$userID'";
   $data = mysqli_query($dbc, $query);

   if(mysqli_num_rows($data) == 0){
    echo '<p class="error">User ID does not exist. Check again.<p>';
    $userID = "";
   }
   else{
    $query = "DELETE FROM userInfo_tb WHERE ID = '$userID'";
    mysqli_query($dbc, $query);
    echo '<p>User Deleted successfully.<p>';
    mysqli_close($dbc);
   }
  }
 }
?>

<html>
<head>
 <title>Ki-Word Admin Page</title>
 <link rel="stylesheet" type="text/css" href="style.css" />
</head>
<body>
 <h3>Ki-Word Admin Page - User Delete</h3>
<form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
 <fieldset>
 <label for="userID">User ID</label>
 <input type="text" id="userID" name="userID" />

 <input type="submit" value="Delete" name="Delete_submit1" />
 </fieldset>
</form>
</body>
</html>