<?php
 mysql_connect("localhost", "root", "12345") or die(mysql_error());
 mysql_select_db("KiWord_db");

 $ID = $_POST["id_data"];
 $PW = $_POST["pass_data"];

 $query = "SELECT Name, Coin, Score FROM userInfo_tb WHERE ID = '$ID' AND PW = '$PW'";
 $data = mysql_query($query) or die(mysql_error());

 if(mysql_num_rows($data) == 0){
  echo "Fail";
 }
 else{
  while($row = mysql_fetch_array($data)){
   echo "Success/";
   echo("$row[Name]/$row[Coin]/$row[Score]");
  }
 }
?>